# Import specific functions or classes to make them accessible from the package level
from .visualize import visualize

# Define package-level variables or setup
__version__ = "0.1"
